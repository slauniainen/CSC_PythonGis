# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 09:16:52 2018

@author: cscuser

CSC Python-gis kurssi 16.1.2018
"""

import os
import numpy as np
import pandas as pd
import geopandas as gpd
from geopandas.tools import geocode 
from shapely.geometry import Point
# import pycrs
from geopy.geocoders import Nominatim

folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
fp = r"addresses.txt"

# Read the data
data = pd.read_csv(os.path.join(folder, fp), sep=';', encoding='utf8')
cols = data.columns

# geocode addresses: geocoding, i.e. converting addresses into coordinates or vice versa
# geocode needs 'geopy'
# Geocode a set of strings and get a GeoDataFrame of the resulting points.
geo = geocode(data['addr'], provider='nominatim')

# to join two tables together based on the index of those DataFrames. 
# must have same number of records in our DataFrames and that the order of the
# records should be the same in both DataFrames.
# .merge() examples; https://geo-python.github.io/2017/lessons/L6/exercise-6-hints.html#joining-data-from-one-dataframe-to-another
geo = geo.join(data)
geo.plot()
geo.to_file(os.path.join(folder, r'addresses.shp'))

#%% Test geopy

geolocator = Nominatim()
#location = geolocator.geocode("Hampträskintie 15C 01150, Sipoo")
#print(location.address)

# iterate over rows in data and add column 'geometry' to add points
#geo1 = gpd.GeoDataFrame(columns=geo.columns)
data1 = data.copy()
data1 = data1.assign(geometry=None, address=None)

for idx, row in data1.iterrows():
    print(idx, row)
    location = geolocator.geocode(row['addr'])
    if location:
        data1.loc[idx, 'geometry'] = Point(location.longitude, location.latitude)
        data1.loc[idx, 'address'] = location.address
    else:
        data1.loc[idx, 'geometry'] = None

data1 = gpd.GeoDataFrame(data1, geometry='geometry')
data1.crs = {'init': 'epsg:4326'}
data1.plot()
data1.to_file(os.path.join(folder, r'addresses1.shp'))
