# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 15:18:11 2018

@author: cscuser
multi-layer interactive plot with bokeh
"""
import os
from bokeh.plotting import figure, save
from bokeh.models import GeoJSONDataSource, ColumnDataSource, HoverTool, LogColorMapper
from bokeh.palettes import Spectral9  as palette  # color palette
import geopandas as gpd
import pysal as ps
import numpy as np

# File paths
dirpath = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
grid_fp = r"TravelTimes_to_5975375_RailwayStation.shp"
point_fp = r"Datae5\addresses.shp"
metro_fp = r"Datae5\metro.shp"

# Read files
grid = gpd.read_file(os.path.join(dirpath, grid_fp))
points = gpd.read_file(os.path.join(dirpath, point_fp))
metro = gpd.read_file(os.path.join(dirpath, metro_fp))

#reproject
grid = grid.to_crs(epsg=3067)
points = points.to_crs(epsg=3067)
metro = metro.to_crs(epsg=3067)

# classify data using pysal
grid = grid.replace(-1, 999)
breaks =[ x for x in range(5, 200, 5)]  # 5 min intervals

# create classifier object and classify
classifier = ps.User_Defined.make(bins=breaks)
pt_classif = grid[['pt_r_t']].apply(classifier)

pt_classif.columns = ['tclass']
grid = grid.join(pt_classif)

point_src = GeoJSONDataSource(geojson=points.to_json())
metro_src = GeoJSONDataSource(geojson=metro.to_json())
grid_src = GeoJSONDataSource(geojson=grid.to_json())

# plot classified grid and point + line objects
p = figure(title="Traveltimes in Helsinki")
# remove gridlines
p.grid.grid_line_color = None
# create colormapper
color_mapper = LogColorMapper(palette=palette)

p.patches('xs', 'ys', source=grid_src, name='traveltimes',
          fill_color={'field': 'tclass', 'transform': color_mapper},
          line_color='black', line_width=0.03)
save(p, 'traveltimes.html')

# Add metro on top of the same figure
p.multi_line('xs', 'ys', source=metro_src, color="red", line_width=2)

# Add points on top (as black points)
p.circle('xs', 'ys', size=10, source=point_src, color="black")

# Output filepath
save(p, filename='linemap2.html')