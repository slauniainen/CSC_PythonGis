# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 12:40:38 2018

@author: cscuser
Lesson 6: create raster mosaic from dem subtiles

"""
import numpy as np
import os
import glob
import rasterio
import rasterio.plot as rp
import matplotlib.pyplot as plt
import geopandas as gpd

# for clipping raster with polygon & merging rasters
from rasterio.mask import mask
from rasterio.merge import merge
from shapely.geometry import box
import geopandas as gpd
from fiona.crs import from_epsg

# for open streetmap & zonal statistics
from rasterstats import zonal_stats
import osmnx as ox

eps = np.finfo(float).eps

dirpath = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data\Download'
outfile = r'Helsinki_DEM_2x2m_Mosaic.tif'

# Make a search criteria to select the DEM files, get list 
search_criteria = "L*.tif"
q = os.path.join(dirpath, search_criteria)
print(q)
dem_fps = glob.glob(q)
print(dem_fps, type(dem_fps))

# open files using rasterio.open
src_files_to_mosaic = []

for fp in dem_fps:
    src = rasterio.open(fp)
    src_files_to_mosaic.append(src)

# Merge function returns a single mosaic array and the transformation info
mosaic, out_trans = merge(src_files_to_mosaic)
rp.show(mosaic, cmap='terrain')

# Copy the metadata from last scr file
out_meta = src.meta.copy()

# Update the metadata
out_meta.update({"driver": "GTiff",
                 "height": mosaic.shape[1],
                 "width": mosaic.shape[2],
                 "transform": out_trans,
                 "crs": "+proj=utm +zone=35 +ellps=GRS80 +units=m +no_defs "
                  }
                 )
# Write the mosaic raster to disk
with rasterio.open(os.path.join(dirpath, outfile), "w", **out_meta) as dest:
    dest.write(mosaic)
    
# read file into dem, print metadata
dem = rasterio.open(os.path.join(dirpath, outfile))
print(dem.meta)
rp.show(dem)

z = np.squeeze(dem.read())
plt.figure()
plt.imshow(z); plt.colorbar(); plt.title('elev m')

#%% compute zonal statistics

kallio_q = "Kallio, Helsinki, Finland"
pihlajamaki_q = "Pihlajamäki, Malmi, Helsinki, Finland"

# read open streetmap data into gpd.GeoDataFrame
kallio = ox.gdf_from_place(kallio_q)
pihlajamaki = ox.gdf_from_place(pihlajamaki_q)

# Reproject the regions to same CRS as the DEM
kallio = kallio.to_crs(crs=dem.crs.data)
pihlajamaki = pihlajamaki.to_crs(crs=dem.crs.data)

# plot dem and overlay polygons
ax = rp.show((dem, 1))
kallio.plot(ax=ax, facecolor='None', edgecolor='red', linewidth=2)
pihlajamaki.plot(ax=ax, facecolor='None', edgecolor='blue', linewidth=2)
plt.show()

# compute statistics within polygns
zs_kallio = zonal_stats(kallio, dem.read(1), affine=dem.affine, stats=['min', 'max', 'mean', 'median', 'majority'])
zs_pihlajamaki = zonal_stats(pihlajamaki, dem.read(1), affine=dem.affine, stats=['min', 'max', 'mean', 'median', 'majority'])