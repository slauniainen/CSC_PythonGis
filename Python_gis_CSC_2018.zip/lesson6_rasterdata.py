# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 09:27:17 2018

@author: cscuser
Lecture6
Raster data analysis
"""

import os
import urllib
import numpy as np
import rasterio
import rasterio.plot as rp
import matplotlib.pyplot as plt

# for clipping raster with polygon & merging rasters
from rasterio.mask import mask
from shapely.geometry import box
import geopandas as gpd
from fiona.crs import from_epsg
import pycrs
eps = np.finfo(float).eps

folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data\Download'
fp = 'Helsinki_masked_p188r018_7t20020529_z34__LV-FIN.tif'  # landsat 7 image
ff = os.path.join(folder, fp)

# https://etsin.avointiede.fi/storage/f/paituli/latuviitta/Landsat_kanavat.pdf

# download raster dataset
raster = rasterio.open(ff, mode='r')

# check properties
crs = raster.crs

affine = raster.affine
trf = raster.get_transform

# dimensions, bounds
height, width = raster.height, raster.width
bounds = raster.bounds  # BoundingBox(left=698592.0, bottom=6656859.0, right=735300.0, top=6697870.5)

# driver, i.e. format, metadata
driver = raster.driver  # GTiff
meta = raster.meta
print(meta)

# channels. i.e. bands
band_cnt = raster.count

# print datatypes
{i: dtype for i, dtype in zip(raster.indexes, raster.dtypes)}


# visualize raster
rp.show(raster)

rp.show((raster, 4), cmap='Reds')
rp.show((raster, 3), cmap='Greens')
rp.show((raster, 1), cmap='Blues')

# plot histogram
rp.show_hist(raster, bins=50, lw=0.0, stacked=False, alpha=0.3, histtype='stepfilled', title="Histogram")

#%% get data from channels and compute statistics
#red = 3
#nir = 4
#ir = 5
red = raster.read(3)
nir = raster.read(4)

array = raster.read()

# Calculate statistics for each band
band = raster.read()
stats = []

k = 1  # bands are indexed from 1 as in GDAL
for band in array:
    stats.append({
                'band': k,
                'min': band.min(),
                'mean': band.mean(),
                'median': np.median(band),
                'max': band.max()})
    k += 1
print(stats)

#%% do some raster calculations

red = red.astype(float)
nir = nir.astype(float)

# compute ndvi
ndvi =  (nir - red ) / ( nir + red + eps)

# where ndvi is > 0? these should be land areas
ndvi_p = ndvi.copy()
ndvi_p[ndvi_p <= 0] = np.NaN

plt.imshow(ndvi); plt.colorbar(); plt.title('NDVI')
plt.show()

# plot dnvi >0 so that highest and lowest 2.5 percent are not within colorbar
# lims = np.nanpercentile(ndvi_p, [2.5, 97.5])
plt.imshow(ndvi_p); plt.colorbar(); plt.title('NDVI > 0 ')
plt.show()

#%% Masking / clipping raster
# check also gdat.Translate

def getFeatures(gdf):
    """Function to parse features from GeoDataFrame in such a manner that rasterio wants them"""
    import json
    return [json.loads(gdf.to_json())['features'][0]['geometry']]

infile = os.path.join(folder, 'p188r018_7t20020529_z34__LV-FIN.tif')
outfile = os.path.join(folder, 'Helsinki_masked_p188r018_7t20020529_z34__LV-FIN_v2.tif')
outfile1 = os.path.join(folder, 'Helsinki_masked_p188r018_7t20020529_z34__LV-FIN_v1.tif')

data = rasterio.open(infile)
rp.show((data, 4), cmap='terrain')

# create polygon to clip subset of raster

minx, miny = 24.6, 60.0
maxx, maxy = 25.2, 60.30
bbox = box(minx, miny, maxx, maxy)

poly = gpd.GeoDataFrame({'geometry': bbox}, index=[0], crs=from_epsg(4326))

#reproject to same geometry as data
poly = poly.to_crs(crs=data.crs.data)

coords = getFeatures(poly)

# clip 'data' using mask. mask wants shapes as json format
#[{'coordinates': [[[734161.3075978339, 6658848.823903588],
#    [732036.1474110243, 6692214.550925391],
#    [698912.2280840294, 6690253.027475534],
#    [700733.5832412266, 6656875.248540204],
#    [734161.3075978339, 6658848.823903588]]],
#  'type': 'Polygon'}]
# create mask for clipped raster
out_img, out_transform = mask(raster=data, shapes=coords, crop=True, all_touched=False, invert=False)
# mask for non-clipped raster where mask is inverted, i.e. contains pixels not overlapping the mask
out_img1, out_transform1 = mask(raster=data, shapes=coords, crop=False, all_touched=False, invert=True)
out_meta = data.meta
epsg_code = int(out_meta['crs']['init'][5:])

#update out_meta
out_meta.update({"driver": "GTiff",
            "height": out_img.shape[1],
            "width": out_img.shape[2],
            "transform": out_transform,
            "crs": from_epsg(epsg_code)}
    )

# write to files
with rasterio.open(outfile, "w", **out_meta) as dest:
    dest.write(out_img)

with rasterio.open(outfile1, "w", **out_meta) as dest:
    dest.write(out_img1)

# close data and outfile
data.close()

# re-import clipped rasters, plot to compare and close
clip = rasterio.open(outfile)
clip1 = rasterio.open(outfile1)
rp.show(clip)
rp.show(clip1)

clip.close()
clip1.close()
