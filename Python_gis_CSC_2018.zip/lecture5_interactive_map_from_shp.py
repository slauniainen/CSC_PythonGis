# -*- coding: utf-8 -*-
"""
Created on Wed Jan 17 14:35:36 2018

@author: cscuser

Lecture 5: interactive map from shapefile
"""
import os
import geopandas as gpd
from bokeh.plotting import save, figure
from bokeh.models import GeoJSONDataSource, HoverTool, 
from bokeh.models.sources import ColumnDataSource

dirpath = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data\datae5'
address_pf = r'addresses.shp'

def getLineCoords(row, geom, coord_type):
    """Returns a list of coordinates ('x' or 'y') of a LineString geometry"""
    if coord_type == 'x':
        return list( row[geom].coords.xy[0] )
    elif coord_type == 'y':
        return list( row[geom].coords.xy[1] )
    

infile = os.path.join(dirpath, address_pf)



# read data & reproject
addr = gpd.read_file(infile)
addr = addr.to_crs(epsg=3067)  # ETRS89 / ETRS-TM35FIN

# convert datatype into bokeh-suitable format
addr_geoj = addr.to_json()
point_src =  GeoJSONDataSource(geojson=addr_geoj)
point_src.pprint()
# create an interactive map of the points

p = figure(title='station map')
p.circle(x='x', y='y', source=point_src, size=20)

# add hovertool to p
my_hover = HoverTool()
my_hover.tooltips = [('Station', '@address')]
# my_hover.tooltips = [('Label1', '@col1'), ('Label2', '@col2'), ('Label3', '@col3')]
p.add_tools(my_hover)

save(p, filename='pointmaptest.html')

#%% add metrolines
metro_fp = r'metro.shp'
# Read the data
metro = gpd.read_file(os.path.join(dirpath, metro_fp))
# get coordinates of nodes
metro['x'] = metro.apply(getLineCoords, geom='geometry', coord_type='x', axis=1)
metro['y'] = metro.apply(getLineCoords, geom='geometry', coord_type='y', axis=1)

m_df = metro.drop('geometry', axis=1).copy()

# columnDataSource
msource = ColumnDataSource(m_df)

p = figure(title="A map of the Helsinki metro")

# Add the lines to the map from our 'msource' ColumnDataSource -object
p.multi_line('x', 'y', source=msource, color='red', line_width=4)

# Output filepath
save(p, filename='linemap.html')