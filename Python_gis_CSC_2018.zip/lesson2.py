# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 11:46:08 2018

@author: cscuser
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import geopandas as gpd

# input and output files
folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
shp = r'DAMSELFISH_distributions.shp'

fn = os.path.join(folder, shp)

# output filename
fo = r'leucorus.shp'
fo = os.path.join(folder, fo)

# read shp-file fn using gpd.read

data = gpd.read_file(fn)

# print data columns
print('data.columns: ', data.columns)
# print crs
data.crs
# print first 4 rows
data.head(4) # shows first 5 rows by defauls
# plot geometries
data.plot()
data.geometry.head()

# select spefies leucorus and save subset to file
leuco = data[data.SPECIES_NA == 'leucorus']
leuco.to_file(fo)

# print areas of subset leuco
for index, row in leuco.iterrows():
    poly_area = row['geometry'].area
    print("Polygon area at index {0} is: {1:.3f}".format(index, poly_area))

# let's add column 'area' into data
data['area'] = data.area
data['area'].loc[0:2]
data['centroid'] = data.centroid
# plot centroid points
data.set_geometry('centroid').plot()

# let's select subset of data

selection = data.loc[data['YEAR']==2010, ['YEAR', 'geometry', 'FAMILY_NAME', 'GENUS_NAME',
                                         'SPECIES_NAME']]

#%% create new geodataframe

centroids = data[['centroid', 'YEAR']]

centroids = gpd.GeoDataFrame(centroids.rename(columns={'centroid': 'geometry'}), crs=data.crs)
centroids.plot()

#%% read example data

world = gpd.read_file(gpd.datasets.get_path('naturalearth_lowres'))
cities = gpd.read_file(gpd.datasets.get_path('naturalearth_cities'))

cities.to_crs(world.crs)

# plot countries and capitals
# plt.figure(1)
# plt.clf()
# base = world.plot(color='white', edgecolor='black')
base = world.plot(column='gdp_md_est', cmap='OrRd', scheme='quantiles')
cities.plot(ax=base, marker='o', color='b', markersize=5)

fig, ax = plt.subplots()
ax.set_aspect('equal')
world.plot(ax=ax, color='white', edgecolor='black')
cities.plot(ax=ax, marker='o', color='red', markersize=5)
plt.show()

#%% crs re-projection

fig, ax1 = plt.subplots(nrows=2, ncols=1)
world.plot(ax=ax1[0]); plt.title(str(world.crs['init']))

world_mercator = world.copy()
world_mercator = world_mercator.to_crs({'init': 'epsg:3395'})# world.to_crs(epsg=3395) would also work

world_mercator.plot(ax=ax1[1]); plt.title(str(world_mercator.crs['init']))