# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 11:30:39 2018

@author: cscuser
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import shapely
from shapely.geometry import Point, LineString, Polygon
from shapely.geometry import MultiPoint, MultiLineString, MultiPolygon, box


def getCentroid(x):
    """
    Args:
        x shapely.geometry -object
    Returns:
        centroid of the geometry object
    create a function called getCentroid() that takes any kind of Shapely's
    geometric -object as input and returns a centroid of that geometry.
    Demonstrate the usage of the function.
    """
    
    if isinstance(x, Point) or isinstance(x, LineString) or isinstance(x, Polygon):
        print('the centroid of %s x is: ' % (x.geom_type), x.centroid)
        return x.centroid
    else:
        print('The input is not valid geometry')
        
def getArea(x):
    """
    takes a Shapely's Polygon -object as input and returns the area of
    that geometry. Demonstrate the usage of the function.
    """
    if isinstance(x, Polygon):
        print('The area of %s x is: ' % (x.geom_type), x.area)
        return x.area