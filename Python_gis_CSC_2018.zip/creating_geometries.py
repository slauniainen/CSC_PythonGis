# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 13:53:00 2018

@author: cscuser
"""

import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, Polygon
from fiona.crs import from_epsg

geo = gpd.GeoDataFrame(columns=['geometry', 'city', 'population', 'country'])
#geo['geometry'] = None

# create Helsinki from coordinates
coordinates = [(24.950899, 60.169158), (24.953492, 60.169158), 
               (24.953510, 60.170104), (24.950958, 60.169990)]

# Create a Shapely polygon from the coordinate-tuple list
poly = Polygon(coordinates)

# let's put this as first element of 'geo'
geo.loc[0, ['geometry', 'city', 'population', 'country']] = [poly, 'Helsinki', 
                                                           1500000, 'Finland']
# add few columns
geo = geo.assign(area=None, centroid=None)
geo.loc[0, 'area'] = poly.area
geo.loc[0, 'centroid'] = poly.centroid
geo.crs = from_epsg(4326)  # decimal degrees
