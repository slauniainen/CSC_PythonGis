# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 09:36:27 2018

@author: cscuser

Open Streetmap -tools
https://github.com/gboeing/osmnx

"""

import osmnx as ox
import matplotlib.pyplot as plt
import geopandas as gpd

place_name = "Kamppi, Helsinki, Finland"

graph = ox.graph_from_place(place_name, network_type='walk')
nodes, edges = ox.graph_to_gdfs(graph)

# type(graph)
#networkx.classes.multidigraph.MultiDiGraph
# A DiGraph is a data type that stores nodes and edges with optional data, or attributes

# plot 
fig, ax = ox.plot_graph(graph)
plt.tight_layout()

# read buildings etc
area = ox.gdf_from_place(place_name)

buildings = ox.buildings_from_place(place_name)

type(area)
type(buildings)

#%% plot something

fig, ax = plt.subplots()

area.plot(ax=ax, facecolor='black')
edges.plot(ax=ax, linewidth=1, edgecolor='#BC8F8F')
buildings.plot(ax=ax, facecolor='khaki', alpha=0.7)
plt.tight_layout()

# look type of edge
cols = edges.columns
print('streettypes', edges.highway.unique)

