# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.

Learn some basics of shapely.geometry objects

Samuli 15.1.2018
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from shapely.geometry import Point, LineString, Polygon
from shapely.geometry import MultiPoint, MultiLineString, MultiPolygon, box

# import shapely as shp

from descartes.patch import PolygonPatch
#%% define some poiSts
# http://toblerity.org/shapely/manual.html#points

point1 = Point(2.2, 4.1)
point2 = Point(7.2, -25.1)
point3 = Point(9.26, -2.456)
point3D = Point(9.26, -2.456, 0.57)

print('point_type:',type(point1))

# distance between points
dist_1_to_2 = point1.distance(point2)
print('dist_1_to2:', dist_1_to_2)

#%% connect by lines
line1 = LineString([point1, point2, point3])
coords = line1.xy  # returns lie x and y coordinated in arrays
print('coords:', line1.xy, 'length: ', line1.length, 'centroid: ', line1.centroid)
#plt.figure(1)
#plt.plot(line1, 'ro-')

#%% create polygons

# Create a Polygon from the coordinates
poly1 = Polygon([(2.2, 4.2), (7.2, -25.1), (9.26, -2.456)])

# We can also use our previously created Point objects (same outcome)
# --> notice that Polygon object requires x,y coordinates as input
poly2 = Polygon([[p.x, p.y] for p in [point1, point2, point3]])

# Geometry type can be accessed as a String
poly_type = poly1.geom_type

# Using the Python's type function gives the type in a different format
poly_type2 = type(poly1)

# Let's see how our Polygon looks like
print(poly1)
print(poly2)

print("Geometry type as text:", poly_type)
print("Geometry how Python shows it:", poly_type2)

#poly1.exterior
#poly1.interiors
#poly1.bounds

#%% let's create world and a hole on it

world_coords = [(-180., 90.), (-180., -90), (180., -90), (180., 90)]
hole_coords = [(-160., 50.), (-160., -70), (160., -70), (160., 50)]

world = Polygon(shell=world_coords, holes=[hole_coords])

#%% let's create some collections
# multi-point collection
multi_point = MultiPoint(points=[point1, point2, point3])
print('centroid of points. ', multi_point.centroid)
# bounding box; created polygon objec
bbox = box(-180., -180., 180., 180)
