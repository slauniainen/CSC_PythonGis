# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 10:54:34 2018

@author: cscuser

Shapely routines -- gis-course
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from shapely.geometry import Point, LineString, Polygon
from shapely.geometry import MultiPoint, MultiLineString, MultiPolygon, box


def createPointGeom(x_coord=None, y_coord=None, z_coord=None):
    """
    create shapely PointGeom
    """
    if z_coord:
        p = Point(x_coord, y_coord, z_coord)
    else:
        p = Point(x_coord, y_coord)
    return p


def createLineGeom(points=None):
    """
    create shapely LineGeom
    Args:
        list of points
    Returns:
        linegeom
    # Create a function called createLineGeom() that takes a list of Shapely Point
    # objects as parameter and returns a LineString object of those input points.
    # Function should first check that the input list really contains Shapely Point(s).
    # Demonstrate the usage of the function by creating LineString -objects with the
    # function
    """
    if isinstance(points, list):
        if isinstance(points[0], Point):
            print('correct input')
    
            return LineString(points)
    else:
        print('check input')
        return None



def createPolygonGeom(data):
    """
    create shapely Polygon
    Args:
        list of coordinate tuples or list of point objects
    Returns:
        polygon
    Create a function called createPolyGeom() that takes a list of coordinate
    tuples OR a list of Shapely Point objects and creates/returns a Polygon
    object of the input data. Both ways of passing the data to the function
    should be working. Demonstrate the usage of the function by passing data
    first with coordinate-tuples and then with Point -objects.
    """

    if isinstance(data, list):
        if isinstance(data[0], Point):
            print('creating polygon from list of Points')
            pts = [[p.x, p.y] for p in data]
            poly = Polygon(shell=pts)
        if isinstance(data[0], tuple):
            print('creating polygon from list of coord. tuples')
            poly = Polygon(shell=data)
        return poly
            