# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 11:20:18 2018

@author: cscuser

AVAA-data SMEAR II API

https://wiki.helsinki.fi/display/SMEAR/Using+SMEAR+API

"""

import pandas as pd

# define table
table = 'VAR_META'
variables = ['NOX_4', 'SO2_1', 'O3_1']
starttime = 's'
endtime = 'e'
quality = 'ANY'
averaging = '30min'
ave_type = 'ARITHMETIC'

def create_url(table, variables, starttime, endtime, quality='ANY', ave='30min', ave_type='ARITHMETIC'):
    
    v = ','.join(variables)
    url = r'https://avaa.tdata.fi/smear-services/smeardata.jsp?table=%s&variables=%s\
        &from=2017-05-01%2000:00:00&to=2017-05-01%2001:00:00&quality=ANY&averaging=30MIN&type=ARITHMETIC'

#    url = r'https://avaa.tdata.fi/smear-services/smeardata.jsp?table=VAR_META&variables=NOX_4,SO2_1,O3_1&from=2017-05-01%2000:00:00&to=2017-05-01%2001:00:00&quality=ANY&averaging=30MIN&type=ARITHMETIC"

data = pd.read_csv(url)
