# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 11:55:51 2018

@author: cscuser
DATA RECLASSIFICATION

"""
import geopandas as gpd
import pysal as ps
import os
import matplotlib.pyplot as plt

folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
fp = r"TravelTimes_to_5975375_RailwayStation.shp"

# Read the data
data = gpd.read_file(os.path.join(folder, fp))
cols = data.columns

#public transport rush hour time 'pt_r_t'
data.plot(column='pt_r_t')

# remove no data
data = data.loc[data['pt_r_t'] >= 0]

data.plot(column='pt_r_t')

#%% Plot using 9 classes and classify the values using "Fisher Jenks" classification
data.plot(column="pt_r_t", scheme="quantiles", k=9, cmap="RdYlBu", linewidth=0);
plt.title('public transport rush hour travel times')
# Use tight layour
plt.tight_layout()

data.plot(column="walk_d", scheme="quantiles", k=9, cmap="RdYlBu", linewidth=0)
plt.title('walking distance')

#%% create classifier, do the classification
n = 9
classifier = ps.Natural_Breaks.make(k=n)

classification = data[['pt_r_t']].apply(classifier)
classification['pt_r_t'].unique()
classification.columns = ['pt_r_t_nb9']

# join classification to 'data', and plot original and re-classified pt_rt_t
data = data.join(classification)
data.plot(column='pt_r_t', cmap="RdYlBu", legend=True)
data.plot(column='pt_r_t_nb9', cmap="RdYlBu", legend=True)