# -*- coding: utf-8 -*-
"""
Created on Mon Jan 15 14:13:14 2018

@author: cscuser
"""
import numpy as np
import os
import matplotlib.pyplot as plt
import pandas as pd
import geopandas as gpd
import pycrs
from shapely.geometry import Polygon, Point, LineString
from fiona.crs import from_epsg

folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
tf = r'some_posts.csv'


# X -coordinates 
xcoords = [29.99671173095703, 31.58196258544922, 27.738052368164062, 26.50013542175293, 26.652359008789062, 25.921663284301758, 22.90027618408203, 23.257217407226562,
           23.335693359375, 22.87444305419922, 23.08465003967285, 22.565473556518555, 21.452774047851562, 21.66388702392578, 21.065969467163086, 21.67659568786621,
           21.496871948242188, 22.339998245239258, 22.288192749023438, 24.539581298828125, 25.444232940673828, 25.303749084472656, 24.669166564941406, 24.689163208007812,
           24.174999237060547, 23.68471908569336, 24.000761032104492, 23.57332992553711, 23.76513671875, 23.430830001831055, 23.6597900390625, 20.580928802490234, 21.320831298828125,
           22.398330688476562, 23.97638702392578, 24.934917449951172, 25.7611083984375, 25.95930290222168, 26.476804733276367, 27.91069221496582, 29.1027774810791, 29.29846954345703,
           28.4355525970459, 28.817358016967773, 28.459857940673828, 30.028610229492188, 29.075136184692383, 30.13492774963379, 29.818885803222656, 29.640830993652344, 30.57735824584961,
           29.99671173095703]

# Y -coordinates
ycoords = [63.748023986816406, 62.90789794921875, 60.511383056640625, 60.44499588012695, 60.646385192871094, 60.243743896484375, 59.806800842285156, 59.91944122314453,
           60.02395248413086, 60.14555358886719, 60.3452033996582, 60.211936950683594, 60.56249237060547, 61.54027557373047, 62.59798049926758, 63.02013397216797,
           63.20353698730469, 63.27652359008789, 63.525691986083984, 64.79915618896484, 64.9533920288086, 65.51513671875, 65.65470886230469, 65.89610290527344, 65.79151916503906,
           66.26332092285156, 66.80228424072266, 67.1570053100586, 67.4168701171875, 67.47978210449219, 67.94589233398438, 69.060302734375, 69.32611083984375, 68.71110534667969,
           68.83248901367188, 68.580810546875, 68.98916625976562, 69.68568420410156, 69.9363784790039, 70.08860778808594, 69.70597076416016, 69.48533630371094, 68.90263366699219,
           68.84700012207031, 68.53485107421875, 67.69471740722656, 66.90360260009766, 65.70887756347656, 65.6533203125, 64.92096710205078, 64.22373962402344, 63.748023986816406]

# P1. Create a list of x and y coordinate pairs out of xcoords and ycoords
# ------------------------------------------------------------------------
# Coordinate pair can be either a tuple or a list.
# The first coordinate pair in the 'coordpairs' -list should look like: (29.99671173095703, 63.748023986816406)
# Hint: you might want to iterate over items in the lists using a for-loop

# coordpairs = [(xcoords[k], ycoords[k]) for k in range(len(xcoords))]
coordpairs = list(zip(xcoords, ycoords))

# P2. Create a shapely Polygon using the 'coordpairs' -list
# ------------------------------------------------------------------------
poly = Polygon(shell=coordpairs)

# P3. Create an empty GeoDataFrame
# ---------------------------------
geo = gpd.GeoDataFrame(columns=['geometry', 'country'])
geo.loc[0, ['geometry', 'country']] = [poly, 'Finland']
geo.crs = from_epsg(4326)  # decimal degrees

# P4. Insert our 'poly' -polygon into the 'geo' GeoDataFrame using a column name 'geometry' 
# ------------------------------------------------------------------------------------------
geo.loc[0, ['geometry', 'country']] = [poly, 'Finland']
geo.crs = from_epsg(4326)  # decimal degrees

# P5. Save the GeoDataFrame into a new Shapefile called 'polygon.shp'
# --------------------------------------------------------------------
# Note: you do not need to define the coordinate reference system at this time
geo.to_file(r'Data\Finland.shp')

# P6. Plot the polygon using taking advantage of the .plot() -function in GeoDataFrame. Save a PNG figure out of your plot and upload it to your GitHub repository.
# -----------------------------------------------------------------------------------------------------------------------------------------------------------------

ax = geo.plot()
plt.savefig('Finland.png')

#%% read data into pandas dataframe,  create Point objects from lat, lon and
# convert data into GeoDataFrame, save to shp and plot

dat = pd.read_csv(os.path.join(folder, tf), sep=',', header='infer')

a=[]
for k in range(len(dat)):
#    dat['geometry'].loc[k] = Point((dat['lat'].loc[k], dat['lon'].loc[k]))
    a.append(Point((dat['lon'].loc[k], dat['lat'].loc[k])))

dat['geometry'] = a
del a

posts = gpd.GeoDataFrame(dat, geometry='geometry', crs=from_epsg(4326))
posts.to_file(os.path.join(folder, r'Kruger_posts.shp'))

fig, ax = plt.subplots()
ax.set_aspect('equal')
#geo.plot(ax=ax, color='white', edgecolor='black')
posts.plot(ax=ax, marker='o', color='red', markersize=5)
plt.show()
plt.savefig('Kruger_posts.png')

#%% reproject, group by userud, sort by timestamp and compute distance
posts = posts.to_crs({'init': 'epsg:32735'})

# sort data by userid and timestamp
posts = posts.sort_values(['userid', 'timestamp'])
movements = gpd.GeoDataFrame(columns=['geometry', 'userid', 'distance'], crs=posts.crs)
users = np.unique(posts['userid'])

for k in users: 
    # sort group
    a = posts['geometry'][posts['userid'] == k]
    if len(a) > 1:
        line = LineString(list(a))
        movements.loc[k, 'userid'] = k
        movements.loc[k, 'geometry'] = line
        movements.loc[k, 'distance'] = line.length

print('max distance [m]: %.2f' % (np.max(movements['distance'])),
      '\nmin distance [m]: %.2f' % (np.min(movements['distance'])),
      '\nmean distance [m]: %.2f' % (np.mean(movements['distance']))
      )

movements.to_file(r'Posts_distances.shp')
