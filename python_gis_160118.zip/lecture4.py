# -*- coding: utf-8 -*-
"""
Created on Tue Jan 16 11:35:44 2018

@author: cscuser

Lecture 4 examples
"""
import os
import numpy as np
import pandas as pd
import geopandas as gpd
from shapely.geometry import Point, Polygon, LineString, MultiLineString, MultiPoint
from shapely.ops import nearest_points

import matplotlib.pyplot as plt

folder = r'C:\Users\cscuser\Desktop\Python_gis_samuli\Data'
fp = r"PKS_suuralue.kml"

""" function definitions """

def nearest(row, geom_union, df1, df2, geom1_col='geometry', geom2_col='geometry', src_column=None):
    """Find the nearest point and return the corresponding value from specified column."""
    # Find the geometry that is closest
    nearest = df2[geom2_col] == nearest_points(row[geom1_col], geom_union)[1]
    # Get the corresponding value from df2 (matching is based on the geometry)
    value = df2[nearest][src_column].get_values()[0]
    return value

#%% Create Point objects
p1 = Point(24.952242, 60.1696017)
p2 = Point(24.976567, 60.1612500)

# Create a Polygon
coords = [(24.950899, 60.169158), (24.953492, 60.169158), (24.953510, 60.170104), (24.950958, 60.169990)]
poly = Polygon(coords)

# are points within poly?

print('p1 in poly?: ', p1.within(poly))
print('p2 in poly?: ', p2.within(poly))
print('poly contains p1?: ', poly.contains(p1))

#%%

# Create two lines
line_a = LineString([(0, 0), (1, 1)])
line_b = LineString([(1, 1), (0, 2)])

line_a.intersects(line_b)  # boolean
line_a.touches(line_b)
cpt = line_a.intersection(line_b)  # point
print('intersection:', cpt)

multi_line = MultiLineString([line_a, line_b])
multi_line.intersects(multi_line)  # true
multi_line.touches(multi_line)  # false

#%%
gpd.io.file.fiona.drvsupport.supported_drivers['KML'] = 'rw'
polys = gpd.read_file(os.path.join(folder, fp), driver='KML')

southern = polys.ix[polys['Name']=='Eteläinen']
southern.reset_index(drop=True, inplace=True)

fig, ax = plt.subplots()
polys.plot(ax=ax, facecolor='gray');
southern.plot(ax=ax, facecolor='red');

#data.plot(ax=ax, color='blue', markersize=5);

plt.tight_layout();

#%% spatial join operations

fp = r'Vaestotietoruudukko_2015.shp'
# Read the data
pop = gpd.read_file(os.path.join(folder, 'Vaestotietoruudukko_2015',fp))
pop = pop.rename(columns={'ASUKKAITA': 'pop15'})
pop = pop[['pop15', 'geometry']]

# read address data, set its crs and reproject to same crs as pop
addr_fp = r'addresses1.shp'

addr = gpd.read_file(os.path.join(folder, addr_fp))
addr.crs = {'init': 'epsg:4326'}
addr = addr.to_crs(pop.crs)

addr.crs == pop.crs

# Make a spatial join: sjoin(left_df, right_df, how={'left', 'right', 'inner'}, op={‘intersects’, ‘contains’, ‘within’}.)
join = gpd.sjoin(addr, pop, how="inner", op="within')
#save to file

outfp = r"addresses_pop15_epsg3979.shp"

# Save to disk
join.to_file(os.path.join(folder, outfp))

# plot
join.plot(column='pop15', cmap="Reds", markersize=7, scheme='fisher_jenks', legend=True);
plt.title("Amount of inhabitants living close the the point");

# Remove white space around the figure
plt.tight_layout()

#%% nearest neighbour
orig = Point(1, 1.67)

dest1, dest2, dest3 = Point(0, 1.45), Point(2, 2), Point(0, 2.5)
destinations = MultiPoint([dest1, dest2, dest3])
print(destinations)

nearest_geoms = nearest_points(orig, destinations)
print('origin point:', nearest_geoms[0])
print('target point:', nearest_geoms[1])

#%% let's read data and look for nearest centers of polygons

fp1 = "PKS_suuralue.kml"
fp2 = "addresses.shp"
gpd.io.file.fiona.drvsupport.supported_drivers['KML'] = 'rw'

df1 = gpd.read_file(os.path.join(folder, fp1), driver='KML')
df1['centroids'] = df1.centroid
df2 = gpd.read_file(os.path.join(folder, fp2))
df2.crs = df1.crs
df1.crs == df2.crs

# Create unary union from Points, which basically creates a MultiPoint object from the Point geometries.
unary_union = df2.unary_union

df1['nearest_id'] = df1.apply(nearest, geom_union=unary_union, df1=df1, df2=df2, geom1_col='centroids', src_column='id', axis=1)